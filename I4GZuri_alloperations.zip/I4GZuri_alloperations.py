#-*-coding:utf8;-*-
#qpy:console

# print "This is console module"


first_x = int(input("Enter the first number: "));
second_y = int(input("Enter the second number: "));
operator = input("Enter the operator to be performed: ");

def simple_arithmetic(x, y, operator):

    """ 
    This simple calculator performs simple arithmetic operations termed in this program as
    addition, subtraction, division, multiplication, and modulus.
    simply enter the two numbers whose operation are to be carried out as inputs, and
    the name of the operator (as stated above) as the third input. 
    """
  
    if operator == "addition":
        return x + y;
    elif operator == "subtraction":
        return x - y;
    elif operator == "division":
        return x/y;
    elif operator == "multiplication":
        return x * y;
    else:
        return x % y;

print('The result of', operator, 'is ', simple_arithmetic(first_x, second_y, operator));
