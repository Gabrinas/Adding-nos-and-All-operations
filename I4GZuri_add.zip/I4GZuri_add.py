#-*-coding:utf8;-*-
#qpy:console

# print "This is console module"


def add(x, y):
    sumd = x + y; # add the two numbers
    return sumd;  # return the summation 
print("The sum of the two numbers is", add(4, 8));
